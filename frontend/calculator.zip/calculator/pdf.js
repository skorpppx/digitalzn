function money(value, currency) {

    const number = Number(value) || 0;

    return `${number.toLocaleString("fr-FR")} ${currency}`;

}
function createHeader() {

    return `

        <div style="text-align:center;margin-bottom:35px;">

            <h1 style="margin:0;color:#5B4FE8;font-size:34px;">
                DIGITAL ZN
            </h1>

            <div style="color:#666;font-size:18px;">
                Project Quotation
            </div>

        </div>

    `;

}
function createInfo(client, project, date) {

    return `

        <div style="margin-bottom:30px;">

            <p><b>Client :</b> ${client}</p>

            <p><b>Project :</b> ${project}</p>

            <p><b>Date :</b> ${date}</p>

        </div>

    `;

}
function createServicesTable(services) {

    let rows = "";

    services.forEach(service => {

        rows += `

            <tr>

                <td>${service.name}</td>

                <td>${money(service.price, service.currency)}</td>

            </tr>

        `;

    });

    return `

        <h2>Services</h2>

        <table
        style="width:100%;
        border-collapse:collapse;">

            <thead>

                <tr>

                    <th align="left">Service</th>

                    <th align="right">Price</th>

                </tr>

            </thead>

            <tbody>

                ${rows}

            </tbody>

        </table>

    `;

}

function getSelectedServices() {

    const items = getItems();

    return items
        .map((item, index) => {

            if (!checked[index]) return null;

            const qty = qtys[index] || 1;

            return {

                name: item.name,

                category: item.cat,

                qty,

                price: item.price,

                total: item.price * qty

            };

        })
        .filter(Boolean);

}
function createServicesTable(currency) {

    const services = getSelectedServices();

    if (services.length === 0) {

        return "<p>No selected services.</p>";

    }

    let rows = "";

    services.forEach(service => {

        rows += `

        <tr>

            <td>${service.name}</td>

            <td>${service.qty}</td>

            <td>${fmt(service.price)}</td>

            <td>${fmt(service.total)}</td>

        </tr>

        `;

    });

    return `

        <h2>Selected Services</h2>

        <table style="width:100%;border-collapse:collapse;margin-top:15px;">

            <thead>

                <tr>

                    <th align="left">Service</th>

                    <th>Qty</th>

                    <th align="right">Unit Price</th>

                    <th align="right">Total</th>

                </tr>

            </thead>

            <tbody>

                ${rows}

            </tbody>

        </table>

    `;

}




async function exportPDF() {

    const client =
        document.getElementById("client-name").value || "Unknown Client";

    const project =
        document.getElementById("project-name").value || "Untitled Project";

    const date =
        document.getElementById("project-date").value;

    const currency =
        document.getElementById("currency").value;

    const invoice = getInvoice();
    const costs = getCosts();
    const net = getNetProfit();
    const margin = Math.round(net * 0.40);
    const recommend = net + margin;

    const quotation = document.createElement("div");
console.log(getItems());

console.log(checked);

console.log(qtys);

console.log(getInvoice());

console.log(getSelectedServices());
    quotation.style.width = "800px";
    quotation.style.background = "white";
    quotation.style.padding = "50px";
    quotation.style.fontFamily = "Arial";
    quotation.style.color = "#222";

    quotation.innerHTML = `

        <h1 style="text-align:center;color:#5B4FE8;">

            DIGITAL ZN

        </h1>

        <h3 style="text-align:center;">

            Project Quotation

        </h3>

        <hr>

        <p><strong>Client:</strong> ${client}</p>

        <p><strong>Project:</strong> ${project}</p>

        <p><strong>Date:</strong> ${date}</p>

        ${createServicesTable(currency)}

        <hr>

        <h2>Summary</h2>

        <table style="width:100%;">

            <tr>

                <td>Project Total</td>

                <td align="right">${fmt(invoice)}</td>

            </tr>

            <tr>

                <td>Business Costs</td>

                <td align="right">${fmt(costs)}</td>

            </tr>

            <tr>

                <td>Estimated Profit</td>

                <td align="right">${fmt(net)}</td>

            </tr>

            <tr>

                <td>Recommended Price</td>

                <td align="right">${fmt(recommend)}</td>

            </tr>

        </table>

        <hr>

        <div style="text-align:center;">

            Generated by Digital ZN Business Suite

        </div>

    `;

    document.body.appendChild(quotation);
    console.log(quotation.outerHTML);

quotation.style.display = "block";

quotation.style.position = "fixed";

quotation.style.top = "20px";

quotation.style.left = "20px";

quotation.style.zIndex = "99999";
document.body.appendChild(quotation);

await new Promise(resolve => setTimeout(resolve, 300));

await html2pdf()
.set({

    filename: `DigitalZN-${client}.pdf`,

    margin: 8,

    image: {
        type: "jpeg",
        quality: 1
    },

    html2canvas: {
        scale: 2,
        useCORS: true,
        logging: false
    },

    jsPDF: {
        unit: "mm",
        format: "a4",
        orientation: "portrait"
    }

})
.from(quotation)
.save();

quotation.remove();

}